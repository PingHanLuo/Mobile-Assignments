Contributors:
Robin Luo 100998216
Michael Kameoka 100980710

Solutions to assignment#2 in 2017 version of COMP 2601 - Mobile Applications.
This is a social tic-tac-toe game interacts between two mobile devices through a server.

Launch Instructions:

Open the android studio project
Start the server java app
Start 2 Android emulators
You should see other users in the list and by clicking on them you can challenge them to a game
use back to exit and notify the server to disconnect you
