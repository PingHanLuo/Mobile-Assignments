package edu.carleton.COMP2601.communication;

public class NoEventHandler extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6708823595103392249L;

	public NoEventHandler(String msg) {
		super(msg);
	}

}
