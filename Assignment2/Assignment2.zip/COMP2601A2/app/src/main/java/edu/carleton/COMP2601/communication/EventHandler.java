package edu.carleton.COMP2601.communication;

public interface EventHandler {
	public void handleEvent(Event event);
}
